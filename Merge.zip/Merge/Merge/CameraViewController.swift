//
//  CameraViewController.swift
//  Merge
//
//

import UIKit
import AVFoundation

enum CameraPosition {
    case front
    case back
}

typealias CaptureSessionInitializedCompletionHandler = () -> Void
typealias CaptureSessionToggleCompletionHandler = (CameraPosition) -> Void

class CameraViewController: UIViewController, UIGestureRecognizerDelegate {
    
    private var captureSessionController = CameraSessionController()
        
    @IBOutlet weak var captureButton: UIButton!
    @IBOutlet weak var flipCameraButton: UIButton!
    @IBOutlet weak var mergeAndPlaybackButton: UIButton!
    @IBOutlet weak var cameraPreviewView: CameraPreviewView!
    
    @IBOutlet weak var playbackContainerView: UIView!
    @IBOutlet weak var playbackView: UIView!
    
    @IBOutlet weak var loadingContainerView: UIView!
    @IBOutlet weak var loadingLabel: UILabel!
                        
    fileprivate let sessionQueue = DispatchQueue(label: "com.capture.session-queue")
        
    fileprivate var photoCaptureDelegates = [Int64 : PhotoCaptureDelegate]()
    
    var isCapturingWithFrontCamera = false
    
    var avPlayerPlayback = AVQueuePlayer()
    var avPlayerPlaybackTimeObserver: Any?
    var avPlaybackLayer: AVPlayerLayer?
    
    var capturedVideoUrls: [URL] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loadingContainerView.isHidden = true
        playbackContainerView.isHidden = true
        
        initializeCameraViewController()
    }
    
    func initializeCameraViewController() {
                            
        cameraPreviewView.session = captureSessionController.captureSession
                
        sessionQueue.suspend()
        
        AVCaptureDevice.requestAccess(for: AVMediaType.video) { [unowned self] success in
            if !success { return }
            self.sessionQueue.resume()
        }
                
        sessionQueue.async { [unowned self] in
            
            self.setupCaptureSessionController()
            self.captureSessionController.captureSession.startRunning()
        }
    }
            
    func setupCaptureSessionController() {
        
        captureSessionController.initializeCaptureSession(completionHandler: { [weak self] in
            
            guard let self = self else { return }
            
            DispatchQueue.main.async {
                self.cameraPreviewView.cameraPreviewLayer.session = self.captureSessionController.getCaptureSession()
            }
        })
    }
    
    @IBAction func capturePhoto(_ sender: UIButton) {
        
        sessionQueue.async {
            
            let photoSettings = AVCapturePhotoSettings()
            photoSettings.flashMode = .off
            
            if photoSettings.availablePreviewPhotoPixelFormatTypes.count > 0 {
                photoSettings.previewPhotoFormat = [
                    kCVPixelBufferPixelFormatTypeKey as String : photoSettings.availablePreviewPhotoPixelFormatTypes.first!,
                    kCVPixelBufferWidthKey as String : 160,
                    kCVPixelBufferHeightKey as String : 160
                ]
            }
                        
            if self.captureSessionController.photoOutput.isLivePhotoCaptureSupported {
               
                self.captureSessionController.photoOutput.isLivePhotoCaptureEnabled = true
                
                let movieFileName = UUID().uuidString
                let moviePath = (NSTemporaryDirectory() as NSString).appendingPathComponent("\(movieFileName).mov")
                photoSettings.livePhotoMovieFileURL = URL(fileURLWithPath: moviePath)
                
            } else {
                
                return
            }
            
            let photoCaptureDelegate = PhotoCaptureDelegate(with: photoSettings) { [unowned self] (photoCaptureDelegate, asset) in
                self.sessionQueue.async { [unowned self] in
                    self.photoCaptureDelegates[photoCaptureDelegate.requestedPhotoSettings.uniqueID] = .none
                }
            }
            
            photoCaptureDelegate.livePhotoCaptureBegins = { [unowned self] in
                DispatchQueue.main.async {
                    
                    self.loadingContainerView.isHidden = false
                    self.loadingLabel.text = "Saving Live Photo"
                }
            }
            
            photoCaptureDelegate.livePhotoSaved = { [unowned self] in
                
                DispatchQueue.main.async {
                    
                    if let url = photoCaptureDelegate.compressedMovieURL {
                        self.capturedVideoUrls.append(url)
                    }
                    self.loadingContainerView.isHidden = true
                    self.loadingLabel.text = ""
                }
            }
                        
            self.photoCaptureDelegates[photoCaptureDelegate.requestedPhotoSettings.uniqueID] = photoCaptureDelegate
            self.captureSessionController.photoOutput.capturePhoto(with: photoSettings, delegate: photoCaptureDelegate)
        }
    }

    @IBAction func togglePosition(_ btn: UIButton) {
        
        captureSessionController.toggleCamera(completionHandler: { [weak self] cameraPosition in
            
            switch cameraPosition {
            case .front:
                
                print("capturing with front camera")
                
            case .back:
                
                print("capturing with back camera")
            }
        })
    }
}

// MARK: Playback Handlers
extension CameraViewController {
    
    @IBAction func initializeMerge() {
        
        var videoAssets: [AVAsset] = []
        
        for url in capturedVideoUrls {
            
            let videoAsset = AVAsset(url: url)
            videoAssets.append(videoAsset)
        }
        
        if !videoAssets.isEmpty {
            
            self.loadingContainerView.isHidden = false
            self.loadingLabel.text = "Initializing Merge"
            
            DispatchQueue.global(qos: .userInitiated).async {

                self.merge(videos: videoAssets) { url, asset in
                                                    
                    DispatchQueue.main.async {
                        
                        self.loadingContainerView.isHidden = true
                        self.playbackContainerView.isHidden = false
                        
                        self.cleanup(mergedVideoUrl: url)
                        self.play(video: asset.asset)
                    }
                }
            }
        }
    }
    
    @IBAction func endPlayback(_ sender: UIButton) {
        avPlayerPlayback.pause()
        handlePlaybackItemCompletion()
    }
    
    func play(video: AVAsset) {
        
        DispatchQueue.main.async { [unowned self] in
            
            self.avPlayerPlayback.removeAllItems()
            
            let item = AVPlayerItem(asset: video)
            self.avPlayerPlayback.insert(item, after: nil)
                
            self.avPlayerPlayback.actionAtItemEnd = .none
            
            self.avPlaybackLayer?.removeFromSuperlayer()
            
            let playbackLayer = AVPlayerLayer(player: self.avPlayerPlayback)
            playbackLayer.frame = self.playbackView.frame
            playbackLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
            self.playbackView.layer.addSublayer(playbackLayer)
            
            self.avPlaybackLayer = playbackLayer
            
            self.avPlayerPlaybackTimeObserver =
            
            self.avPlayerPlayback.addPeriodicTimeObserver(forInterval: CMTime(value: 1, timescale: 2) , queue: .main, using: { time in
                                                
                if let currentItem = self.avPlayerPlayback.currentItem {
                    
                    let totalDuration = CMTimeGetSeconds(currentItem.duration)
                    let secondsElapsed = CMTimeGetSeconds(time)
                    
                    if totalDuration >= 0 {
                        
                        let progress = CGFloat(secondsElapsed / totalDuration)
                        
                        if progress >= 1 {
                            self.handlePlaybackItemCompletion()
                        }
                    }
                }
            })
                                                
            self.avPlayerPlayback.play()
        }
    }
    
    func handlePlaybackItemCompletion() {
        
        if let playbackTimeObserver = avPlayerPlaybackTimeObserver {
            
            avPlayerPlayback.removeTimeObserver(playbackTimeObserver)
            avPlayerPlaybackTimeObserver = nil
        }
        
        playbackContainerView.isHidden = true
    }
    
    func merge(videos: [AVAsset], completion: @escaping (_ url: URL, _ asset: AVAssetExportSession)->()) {
        
        let videoComposition = AVMutableComposition()
        
        guard let videoCompositionTrack = videoComposition.addMutableTrack(withMediaType: .video, preferredTrackID: Int32(kCMPersistentTrackID_Invalid)),
                let audioCompositionTrack = videoComposition.addMutableTrack(withMediaType: .audio, preferredTrackID: Int32(kCMPersistentTrackID_Invalid))
        else { return }
                
        var lastTime: CMTime = .zero
        var layerInstructions = [AVMutableVideoCompositionLayerInstruction]()
        
        var count = 1
                        
        for video in videos {
          guard let videoTrack = video.tracks(withMediaType: .video)[safe: 0] else { return }
            
            DispatchQueue.main.async {
                self.loadingLabel.text = "Merging \(count)/\(videos.count) Videos"
            }
                    
          if let audioTrack = video.tracks(withMediaType: .audio)[safe: 0] {
            
              do {
                  
                  try audioCompositionTrack.insertTimeRange(CMTimeRangeMake(start: .zero, duration: video.duration), of: audioTrack, at: lastTime)
                                    
              } catch {
                
                  return
              }
          }
                    
            do {
                
                try videoCompositionTrack.insertTimeRange(CMTimeRangeMake(start: .zero, duration: video.duration), of: videoTrack, at: lastTime)
                let layerInstruction = makeVideoCompositionInstruction(videoTrack, asset: video, atTime: lastTime)
                layerInstructions.append(layerInstruction)
                
            } catch {
                
                return
            }
          
          lastTime = CMTimeAdd(lastTime, video.duration)
            
            count += 1
        }
        
        let renderSize = CGSize(width: 720, height: 1280)
        
        let videoInstruction = AVMutableVideoCompositionInstruction()
        videoInstruction.timeRange = CMTimeRangeMake(start: .zero, duration: lastTime)
        videoInstruction.layerInstructions = layerInstructions
        
        let mutableVideoComposition = AVMutableVideoComposition()
        mutableVideoComposition.instructions = [videoInstruction]
        mutableVideoComposition.frameDuration = CMTimeMake(value: 1, timescale: 30)
        mutableVideoComposition.renderSize = renderSize
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .long
        dateFormatter.timeStyle = .short
        
        let id = UUID().uuidString
        
        let mergedURL = NSURL.fileURL(withPath: NSTemporaryDirectory() + "merged-\(id)" + ".mp4")
        
        guard let exporter = AVAssetExportSession(asset: videoComposition, presetName: AVAssetExportPresetHighestQuality) else { return }
        
        exporter.outputURL = mergedURL
        exporter.outputFileType = .mp4
        exporter.videoComposition = mutableVideoComposition
        exporter.shouldOptimizeForNetworkUse = true
        completion(mergedURL, exporter)
        
        DispatchQueue.main.async {
            self.loadingLabel.text = "Exporting Merged Videos"
        }
    }
    
    func makeVideoCompositionInstruction(_ videoTrack: AVAssetTrack, asset: AVAsset, atTime: CMTime) -> AVMutableVideoCompositionLayerInstruction {
        let renderSize = CGSize(width: 720, height: 1280)
        
        let instruction = AVMutableVideoCompositionLayerInstruction(assetTrack: videoTrack)
        
        let assetTrack = asset.tracks(withMediaType: .video)[0]
        let t = assetTrack.preferredTransform
        print(t)
        let assetInfo = orientationFromTransform(t)
        print(assetInfo)
        
        if assetInfo.isPortrait {
            
            let scaleToFitRatio = renderSize.width / assetTrack.naturalSize.height
            let scaleFactor = CGAffineTransform(scaleX: scaleToFitRatio, y: scaleToFitRatio)
            var finalTransform = assetTrack.fixedPreferredTransform.concatenating(scaleFactor)
            
            if assetInfo.orientation == .rightMirrored || assetInfo.orientation == .leftMirrored {
                finalTransform = finalTransform.translatedBy(x: 0, y: -t.ty)
            }
            instruction.setTransform(finalTransform, at: atTime)
            
        } else {
            
            let renderRect = CGRect(x: 0, y: 0, width: renderSize.width, height: renderSize.height)
            let videoRect = CGRect(origin: .zero, size: assetTrack.naturalSize).applying(assetTrack.fixedPreferredTransform)
            
            let scale = renderRect.width / videoRect.width
            let transform = CGAffineTransform(scaleX: renderRect.width / videoRect.width,
                                              y: (videoRect.height * scale) / assetTrack.naturalSize.height)
            let translate = CGAffineTransform(translationX: .zero,
                                              y: ((renderSize.height - (videoRect.height * scale))) / 2)
            
            instruction.setTransform(assetTrack.fixedPreferredTransform.concatenating(transform).concatenating(translate),
                                     at: atTime)
        }
        
        if atTime == .zero {
            instruction.setOpacity(0.0, at: asset.duration)
        }
        
        return instruction
    }
    
    func orientationFromTransform(_ transform: CGAffineTransform) -> (orientation: UIImage.Orientation, isPortrait: Bool) {
        var assetOrientation = UIImage.Orientation.up
        
        var isPortrait = false
        let tfA = transform.a
        let tfB = transform.b
        let tfC = transform.c
        let tfD = transform.d
        
        if tfA == 0 && tfB == 1.0 && tfC == -1.0 && tfD == 0 {
            assetOrientation = .right
            isPortrait = true
        } else if tfA == 0 && tfB == -1.0 && tfC == 1.0 && tfD == 0 {
            assetOrientation = .left
            isPortrait = true
        } else if tfA == 1.0 && tfB == 0 && tfC == 0 && tfD == 1.0 {
            assetOrientation = .up
        } else if tfA == -1.0 && tfB == 0 && tfC == 0 && tfD == -1.0 {
            assetOrientation = .down
        }
        return (assetOrientation, isPortrait)
    }
    
    func cleanup(mergedVideoUrl: URL) {
                                
        do { try FileManager.default.removeItem(at: mergedVideoUrl) }
        catch { print("Unable to remove file at path: \(mergedVideoUrl)") }
    }
}
