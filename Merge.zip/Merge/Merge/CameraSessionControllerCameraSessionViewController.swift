//
//  CameraSessionController.swift
//  Merge
//
//

import Foundation
import AVFoundation

class CameraSessionController: NSObject {
    
    lazy var captureSession = AVCaptureSession()
    
    var videoCaptureDevice: AVCaptureDevice?
    var videoCaptureDeviceInput: AVCaptureDeviceInput?
    
    var audioCaptureDevice: AVCaptureDevice?
    var audioCaptureDeviceInput: AVCaptureDeviceInput?
        
    var cameraPosition = CameraPosition.back
    
    var photoOutput = AVCapturePhotoOutput()
    
    weak var delegate: PhotoCaptureDelegate?
    
    override init() {
        super.init()
        videoCaptureDevice = getBackVideoCaptureDevice()
        audioCaptureDevice = getMicrophoneCaptureDevice()
    }
    
    func getCaptureSession() -> AVCaptureSession {
        return captureSession
    }
    
    func toggleCamera(completionHandler: CaptureSessionToggleCompletionHandler? = nil) {
        
        for input in captureSession.inputs {
            captureSession.removeInput(input)
        }
        
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            
            switch self.cameraPosition {
            case .back:
                if let frontCaptureDevice = self.getFrontVideoCaptureDevice() {
                    self.initializeCaptureSession(videoCaptureDevice: frontCaptureDevice)
                }
                self.cameraPosition = .front
                
                if let connection = self.photoOutput.connection(with: .video) {
                    connection.isVideoMirrored = true
                }
                
            case .front:
                if let backCaptureDevice = self.getBackVideoCaptureDevice() {
                    self.initializeCaptureSession(videoCaptureDevice: backCaptureDevice)
                }
                self.cameraPosition = .back
                      
                if let connection = self.photoOutput.connection(with: .video) {
                    connection.isVideoMirrored = false
                }
            }
            
            completionHandler?(self.cameraPosition)
        }
    }
    
    func initializeCaptureSession(videoCaptureDevice: AVCaptureDevice? = nil, completionHandler: CaptureSessionInitializedCompletionHandler? = nil) {
        
        var tmpVideoCaptureDevice = self.videoCaptureDevice
        
        if let passedVideoCaptureDevice = videoCaptureDevice {
            tmpVideoCaptureDevice = passedVideoCaptureDevice
        }
        
        guard let videoCaptureDevice = tmpVideoCaptureDevice else { return }
        self.videoCaptureDevice = videoCaptureDevice
        guard let videoCaptureDeviceInput = getCaptureDeviceInput(captureDevice: videoCaptureDevice) else { return }
        self.videoCaptureDeviceInput = videoCaptureDeviceInput
        guard captureSession.canAddInput(videoCaptureDeviceInput) else { return }
        
        guard let audioCaptureDevice = audioCaptureDevice else { return }
        self.audioCaptureDevice = audioCaptureDevice
        guard let audioCaptureDeviceInput = getCaptureDeviceInput(captureDevice: audioCaptureDevice) else { return }
        self.audioCaptureDeviceInput = audioCaptureDeviceInput
        guard captureSession.canAddInput(audioCaptureDeviceInput) else { return }
        
        captureSession.addInput(videoCaptureDeviceInput)
        captureSession.addInput(audioCaptureDeviceInput)
                                        
        let photoFileOutput = AVCapturePhotoOutput()
        guard captureSession.canAddOutput(photoFileOutput) else {  return }
        
        captureSession.beginConfiguration()
        
        captureSession.sessionPreset = .photo
        
        captureSession.addOutput(photoFileOutput)
        
        photoFileOutput.isLivePhotoCaptureEnabled = photoFileOutput.isLivePhotoCaptureSupported
        
        if let connection = photoFileOutput.connection(with: .video) {
            if connection.isVideoStabilizationSupported { connection.preferredVideoStabilizationMode = .auto }
            
            connection.videoOrientation = .portrait
            connection.isVideoMirrored = false
        }
                
        captureSession.commitConfiguration()
        
        self.photoOutput = photoFileOutput
        
        captureSession.startRunning()
        completionHandler?()
    }
    
    func stopRunning() {
        captureSession.stopRunning()
    }
    
    func startRunning() {
        captureSession.startRunning()
    }
    
    func cleanUp(outputFileURL: URL) {
        let path = outputFileURL.path
        guard FileManager.default.fileExists(atPath: path) else { return }
        do {
            try FileManager.default.removeItem(atPath: path)
        } catch {
            print("Could not remove file at url: \(outputFileURL)")
        }
    }
    
}

private extension CameraSessionController {
    
    func getBackVideoCaptureDevice() -> AVCaptureDevice? {
        
        if let tripleCamera = AVCaptureDevice.default(.builtInTripleCamera, for: .video, position: .back) {
            return tripleCamera
        }
        
        if let dualWideCamera = AVCaptureDevice.default(.builtInDualWideCamera, for: .video, position: .back) {
            return dualWideCamera
        }
        
        if let dualCamera = AVCaptureDevice.default(.builtInDualCamera, for: .video, position: .back) {
            return dualCamera
        }
        
        if let wideAngleCamera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) {
            return wideAngleCamera
        }
        
        return nil
        
    }
    
    func getFrontVideoCaptureDevice() -> AVCaptureDevice? {
        
        if let trueDepthCamera = AVCaptureDevice.default(.builtInTrueDepthCamera, for: .video, position: .front) {
            return trueDepthCamera
        }
        
        if let wideAngleCamera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front) {
            return wideAngleCamera
        }
        
        return nil
        
    }
    
    func getMicrophoneCaptureDevice() -> AVCaptureDevice? {
        
        if let microphoneCaptureDevice = AVCaptureDevice.default(for: .audio) {
            return microphoneCaptureDevice
        }
        
        return nil
        
    }
    
    func getCaptureDeviceInput(captureDevice: AVCaptureDevice) -> AVCaptureDeviceInput? {
        do {
            let captureDeviceInput = try AVCaptureDeviceInput(device: captureDevice)
            return captureDeviceInput
        } catch let error {
            print("Failed to get capture device input with error \(error)")
        }
        return nil
    }
}

