//
//  CameraPreviewView.swift
//  Merge
//
//

import UIKit
import AVFoundation

class CameraPreviewView: UIView {
    
    override static var layerClass: AnyClass {
        return AVCaptureVideoPreviewLayer.self
    }
    
    var cameraPreviewLayer: AVCaptureVideoPreviewLayer {
        return layer as! AVCaptureVideoPreviewLayer
    }
            
    var session: AVCaptureSession? {
        get { return cameraPreviewLayer.session }
        set { cameraPreviewLayer.session = newValue }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        cameraPreviewLayer.videoGravity = .resizeAspectFill
    }
}
